import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

/* this program demonstrates Arrays
 * and sending to two different prt files.
 * It is a pop fundraiser for IHCC Majors */

public class PopSalesArray {
	static Scanner myScanner, newScanner;
	static NumberFormat nf;
	static boolean eof = false;
	static PrintWriter salespw;
	static PrintWriter errorpw;
	static String error;
	static Date iDate;
	static LocalDate userDate;
	static LocalDate today = LocalDate.now();
	static SimpleDateFormat dtf;
	static boolean valid = true;
	
	static int EPCTR = 0, PCTR=0, cBottles=0, cErrCtr=0, i=0;
	
	static String iLName, iFName, iAdd, iCity, iState, iZip, iTeam, iString, iString2, iRec, oDeposit, oTotal, opopTypeTotal, opopTypeArray, oteamTotal;
	static String oMessage;
	static int iPopType, iZip2,  iCases, errCode, index, teamindex;
	static String iZipA, iZipB;
	
	static double cDeposit, cTotal;
	
	static String[] errMessage = {
			"Blank last name", 
			"Blank first name",
			"Blank Address", 
			"Blank City",
			"non valid state",
			"Blank Zip", 
			"Pop type not numeric",
			"Pop type not 1-6", 
			"Cases not numeric",
			"Case amount lower than 1",
			"Non valid team name",
			"ZIP IS NOT NUMERIC"};
	//static int[] errCode = { 0,1,2,3,4,5,6,7,8,9,10};
	
	
	static String[] popTypeArray = {"Coke", "Diet Coke", "Mello Yellow", "Cherry Coke","Diet Cherry Coke","Sprite"};
	static int[] popNum = { 1, 2, 3, 4, 5, 6};
	
	static String[] state =       {"IA", "IL", "MI", "MO", "NE", "WI"};
	static double[] depositRate = { 0.05, 0.00, 0.10, 0.00, 0.05, 0.05 };
	
	static String[] team = {"A", "B", "C", "D", "E"};
	
	static double[] popTypeTotal = new double [6];
	
	static double[] teamTotal = new double [5];
	
	
	
	
	public static void main(String[] args) {
		
		init();
		
		while(!eof) {
			val();
			if (valid == true) {
				calcs();
				output();
			}
			else {
				errorReport();
			}
				input();				
						
		}//while !eof end
	
		closing();
		System.out.println("stop");
	}//main end
	
	public static void init( ) {
		
		iDate = new Date();
		
		dtf = new SimpleDateFormat("MM/dd/yyyy");
		
		nf = NumberFormat.getCurrencyInstance(java.util.Locale.US);
		
		//open file
		try {
			myScanner = new Scanner(new File("JAVPOPSLB.dat"));
			myScanner.useDelimiter(System.getProperty("line.separator"));
		}//try end 
		catch (FileNotFoundException e1) {
			System.out.println("File error");
			System.exit(1);
		}//catch end
		
		try {
			salespw = new PrintWriter(new File ("JAVPOPSLB.prt"));
		}//try end
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}//catch end
		
		try {
			errorpw = new PrintWriter(new File ("JAVPOPERB.prt"));
		}//try end
		catch (FileNotFoundException e) {
			System.out.println("Output file error");
		}//catch end
		
		heading();
		headingError();
		
		// initial read
		input();
		
	}// init end
		
	public static void heading() {
		PCTR ++;
		salespw.format("%-22s%31s%11s%44s%4s%2s%n",dtf.format(iDate)," ","ALBIA SOCCER CLUB FUNDRAISER", " ","PAGE",PCTR);
		salespw.format("%-8s%50s%16s%50s%n","JAVJCC05"," ","CHRISTY DIVISION"," ");
		salespw.format("%59s%13s%54s%n"," ","SALES REPORT"," ");
		salespw.println(" ");
		salespw.format("%-3s%9s%8s%10s%7s%4s%8s%5s%2s%8s%3s%8s%13s%8s%8s%11s%6s%11s%3s%n"," ","LAST NAME"," ", "FIRST NAME"," ","CITY"," ","STATE"," ","ZIP CODE"," ","POP TYPE"," ","QUANTITY"," ","DEPOSIT AMT"," ","TOTAL SALES"," ");
		
		for (int i=1; i<=132;i++) {
			salespw.print("_"); 
		}//pretty line end
		salespw.println(" ");
		salespw.println(" ");
		
		}// heading end
	
	public static void headingError() {
		EPCTR ++;
		errorpw.format("%-22s%31s%11s%44s%4s%2s%n",dtf.format(iDate)," ","ALBIA SOCCER CLUB FUNDRAISER", " ","PAGE",PCTR);
		errorpw.format("%-8s%50s%16s%50s%n","JAVJCC05"," ","CHRISTY DIVISION"," ");
		errorpw.format("%59s%12s%54s%n"," ","ERROR REPORT"," ");
		errorpw.format("%-12s%60s%17s%42s%n","ERROR RECORD"," ","ERROR DESCRIPTION"," ");
		for (int i=1; i<=132;i++) {
			errorpw.print("-");
		}//pretty line end
		errorpw.println(" ");
		
		//zero out arrays
		
		for(int i = 0; i < popTypeTotal.length; i++) {
			popTypeTotal[i] = 0;
		}
		
		for(int i = 0; i < teamTotal.length; i++) {
			teamTotal[i] = 0;
		}
		
	}// heading error
	
	public static void input( ) {
		
		valid = true;
		
		String record;
		
		if (myScanner.hasNext()) {
			record = myScanner.next();
			iRec = record;
			iLName = record.substring(0,15);	//file position 1 - 25
			iFName = record.substring(15,30);	//25 - 50
			iAdd = record.substring(30,45);
			iCity = record.substring(45,55);
			iState = record.substring(55,57);
			iZip = record.substring(57,66);
			
			iString = record.substring(66,68);
			//iPopType = Integer.parseInt(iString);
			
			iString2 = record.substring(68,70);
			//iCases = Integer.parseInt(iString2);
			
			iTeam = record.substring(70,71);
					
			iZipA = record.substring(57,62);
			iZipB = record.substring(62,66);
			
		}//if end
		else {
			eof=true;	//no more records so set eof to true	
		}
	}//input end
		
	public static void val() {
		// validation
		if (iLName.length() > 15 || iLName.trim().length() < 1) {
			oMessage = errMessage[0];
			//another way to do it
			errCode = 0;
			valid = false;
			return;
		}	
		if (iFName.length() > 15 || iFName.trim().length() < 1) {
			errCode = 1;
			valid = false;
			return;
		}	
		if (iAdd.length() > 15 || iAdd.trim().length() < 1) {
			errCode = 2;
			valid = false;
			return;
		}	
		if (iCity.length() > 10 || iCity.trim().length() < 1) {
			errCode = 3;
			valid = false;
			return;
		}	
		
		for ( int i=0;i<state.length;i++) {
			
			if(iState.equals(state[i])) {
				break;
			}//if end
			
			if (i == state.length-1) {
				errCode = 4;
				valid = false;
				return;
				}
			
		}//for end
		
		
		if (iZip.length() > 9 || iZip.trim().length() < 9) {
			errCode = 5;
			valid = false;
			return;
		}
		
		try { 
			
			iPopType = Integer.parseInt(iString);
		
		}//try end
		catch (Exception e) {
	
			errCode = 6;
			valid = false;
			return;
		}
		
		if (iPopType < 1 || iPopType > 6) {
			errCode = 7;
			valid = false;
			return;
		}
		else {index = iPopType;
		
		}
		try { 
			
			iCases = Integer.parseInt(iString2);
		
		}//try end
		catch (Exception e) {
			errCode = 8;
			valid = false;
			return;
		}
		
		if (iCases < 1 || iCases > 99) {
			errCode = 9;
			valid = false;
			return;
		}
		
		for ( int i=0;i<team.length;i++) {
			
			if(iTeam.equals(team[i])) {
				teamindex = i;
				break;
			}//if end
			
			if (i == team.length-1) {
				errCode = 10;
				valid = false;
				return;
				}
			
		}//for end
		
		
		
		try { 
			
			iZip2 = Integer.parseInt(iZip);
		
		}//try end
		catch (Exception e) {
	
			errCode = 11;
			valid = false;
			return;
		}
		
		
	}//val end

	public static void calcs( ) {
		
		cBottles = iCases * 24;
		
		for (int i=0;i<state.length;i++) {
			if(iState.equals(state[i])) {
				cDeposit =  cBottles * depositRate[i];
			}//if end		
		}//for end
					
		
		cTotal = (18.71 * iCases) + cDeposit;
		
		popTypeTotal[index-1] = popTypeTotal[index-1] + cTotal;
		
		teamTotal[teamindex] += cTotal;
		
	}//calcs end
	
	public static void output( ) {
		
		oDeposit = nf.format(cDeposit);
		oTotal = nf.format(cTotal);
		salespw.format("%-3s%15s%2s%15s%2s%10s%3s%2s%4s%5s%1s%4s%1s%16s%8s%2d%13s%7s%9s%9s%n"," ",iLName," ", iFName," ", iCity," ",iState, " ",iZipA,"-",iZipB," ", popTypeArray[index-1]," ",iCases," ",oDeposit," ", oTotal);
		
	}//output end
	
	public static void GrandTotals( ) {
		
		
		
		salespw.println(" ");
		salespw.println(" ");
		salespw.println(" ");
		heading();
		salespw.format("%-13s%121s%n", "GRAND TOTALS:"," ");
		salespw.println(" ");
		
		int	Z = 0;
		for (int i=0;i<popTypeArray.length;i++) {
			
			opopTypeTotal = nf.format(popTypeTotal[i]);
			if (i==3) { 
				salespw.println(" "); 
				salespw.println(" ");
			}
			salespw.format("%-3s%16s%1s%7s%6s", " ", popTypeArray[i]," ", opopTypeTotal," ");
			salespw.print(" ");
			Z=3;
		}
		salespw.println(" ");
		salespw.println(" ");
		
		
		salespw.println(" ");
		salespw.format("%-13s%121s%n", "TEAM TOTALS:"," ");
		salespw.println(" ");
		
		for (int i=0;i<team.length;i++) {
			oteamTotal = nf.format(teamTotal[i]);
			salespw.format("%-3s%2s%16s%n", " ", team[i], oteamTotal);
		}//for end
		
		errorpw.println(" ");
		errorpw.println(" ");
		errorpw.format("%-12s%1s%6s%n", "TOTAL ERRORS"," ", cErrCtr);
		
		
	}//GT end
	
	public static void closing() {
		GrandTotals();
		errorpw.close();
		salespw.close();
	}//closing end
	
	public static void errorReport() {
		cErrCtr = cErrCtr + 1;
		errorpw.format("%-72s%1s%58s%n", iRec," ", errMessage[errCode]);
		//another way to do it
		//errorpw.format("%-72s%1s%60s%n", iRec," ", oMessage);
		
	} // error end
	
}// class end 
